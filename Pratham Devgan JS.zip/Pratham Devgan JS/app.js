// Required modules and libraries
const createError = require("http-errors");
const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const hbs = require("hbs");
const mongoose = require("mongoose");
const passport = require("passport");
const session = require("express-session");
const GoogleStrategy = require("passport-google-oauth20").Strategy;

// Application-specific modules
const indexRouter = require("./routes/index");
const projectsRouter = require("./routes/projects");
const itemsRouter = require("./routes/Items");
const configs = require("./configs/globals");
const User = require("./models/user");

// Initialize Express app
const app = express();

// View engine setup: Using Handlebars
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs");

// Middleware setup
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public"))); // Serve static files

// Session and Passport initialization
app.use(
  session({
    secret: "s2021pr0j3ctTracker", // Session secret key
    resave: false,
    saveUninitialized: false,
  })
);

// Passport initialization for user authentication
app.use(passport.initialize());
app.use(passport.session());

// Passport Strategy for user authentication with Google OAuth
passport.use(User.createStrategy());

passport.use(
  new GoogleStrategy(
    {
      clientID: configs.Authentication.Google.ClientId,
      clientSecret: configs.Authentication.Google.ClientSecret,
      callbackURL: 'http://localhost:3000/auth/google/callback',
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        // Check if user exists in the database
        let user = await User.findOne({ oauthId: profile.id });
        if (!user) {
          // Create new user if not found
          user = new User({
            username: profile.displayName,
            oauthId: profile.id,
            oauthProvider: "Google",
            created: Date.now(),
          });
          await user.save(); // Save the new user
        }
        return done(null, user); // Return user (either new or existing)
      } catch (err) {
        return done(err, null);
      }
    }
  )
);

// Serialize and deserialize user information into session
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Handlebars helper for generating HTML options with a "selected" attribute
hbs.registerHelper("createOptionElement", (currentValue, selectedValue) => {
  const selected = currentValue === selectedValue.toString() ? "selected" : "";
  return new hbs.SafeString(`<option ${selected}>${currentValue}</option>`);
});

// Define routes
app.use("/", indexRouter);  // Home route
app.use("/projects", projectsRouter);  // Projects route
app.use("/items", itemsRouter);  // Items route

// Connect to MongoDB database
mongoose
  .connect(configs.ConnectionStrings.MongoDB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connected to MongoDB!"))
  .catch((err) => console.error(`MongoDB connection error: ${err}`));

// Handle 404 errors (Page not found)
app.use((req, res, next) => {
  next(createError(404)); // Forward 404 errors to error handler
});

// General error handling (development and production environments)
app.use((err, req, res, next) => {
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // Render the error page
  res.status(err.status || 500);
  res.render("error");
});

// Set the port for the app to listen on
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

// Export the app for use in other files (e.g., for testing)
module.exports = app;
