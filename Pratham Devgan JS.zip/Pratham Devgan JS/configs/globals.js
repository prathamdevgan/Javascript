require("dotenv").config();

const configurations = {
  ConnectionStrings: {
    MongoDB: "mongodb+srv://prathamdevgan2004:0x4QvZVk5TRGvN8W@cluster0.i35jy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
  },
  Authentication: {
    Google: {
      ClientId: "522790262232-gb4dc4c969dbs80u9ko3fbkn8i8b2m45.apps.googleusercontent.com",
      ClientSecret: "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",
      CallbackUrl: "http://localhost:3000/auth/google/callback"
    },
  }  
};
module.exports = configurations;
